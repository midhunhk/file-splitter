/* 	JS File for FileSplitter
 * 	------------------------
 *	(c) 2007 Centrum inc Software Solutions R&D
 *
 *	midhunhk@gmail.com
 *	http://www.geocities.com/mhkonline2/
 */
var d = document;
var useCustName = 0;
var useCustDir  = 0; 

/***************************************************/
function gebid(id)
  {  return (d.getElementById(id)); }
function hideElement(id)
  {  gebid(id).style.display = "none"; }
function showElement(id)
  {  gebid(id).style.display = ""; }
/***************************************************/
function checkCustName(){
	if(gebid("in_custNameChk").checked){
		useCustName = 1;
		showElement("fs_custNameInp");
	}
	else{
		useCustName = 0;
		hideElement("fs_custNameInp");
		gebid("in_custNameTxt").value = '';
	}
}
function checkCustDir(){
	if(gebid("in_custDirChk").checked){
		useCustDir = 1;
		showElement("fs_custDirInp");
	}
	else{
		useCustDir = 0;
		hideElement("fs_custDirInp");
		gebid("in_custDirTxt").value = '';
	}	
}
/************************************************************************/
/*Main Function to generate commandline params for the filesplitter exe.*/
/************************************************************************/
function getParams()
{
	var filePath = gebid('in_file').value;
	var command = "data\\fs_binary.exe ";
	
	if(filePath)
	{
		var fileBaseName = filePath.substring(filePath.lastIndexOf('\\')+1,filePath.lastIndexOf('.'));
		var fileBaseType = filePath.substr(filePath.lastIndexOf('.')+1);
			fileBaseType = fileBaseType.toLowerCase();
		var fsWorkingDir = filePath.substring(0,filePath.lastIndexOf('\\'));
		var	indexFile    = filePath.substring(0,filePath.lastIndexOf('.'));
		var subFileTempl = indexFile + '_';
			indexFile   += ".idx";		

		if(fileBaseType == 'idx')
		{ // Join
			if(useCustDir)
			{
				var cd = gebid('in_custDirTxt').value;
				if(cd)
				{
					var custDir = (cd.charAt(cd.length-1)=='\\')?cd.substring(0,cd.length-1):cd;
					filePath = custDir + '\\' + fileBaseName;
				}else{alert('Please specify an existing directory(absolute)...'); return;}
			}
			else filePath = fsWorkingDir + '\\' + fileBaseName;
			if(useCustName)
			{
				var custName = gebid('in_custNameTxt').value;
				if(custName)
				{
					outputFile = filePath.substring(0,filePath.lastIndexOf('\\')+1);
					outputFile = outputFile + custName;
				}else{alert('Please Specify an output file name...'); return;}
			}
			else outputFile = filePath.substr(filePath.lastIndexOf('.'));
			command += ' -J "' + indexFile + '"  "' + outputFile + '" "' + subFileTempl + '" SPLIT 1';
		}
		else if(fileBaseType=='split')
		{ alert('Please select the index file to join the split files...');	 return;}
		else
		{ // Split
			var subFileCount = gebid('in_numParts').value;
			if(subFileCount>100){ alert('Maximum number of parts is 100...'); return;}
			if(isNaN(subFileCount)){ alert('The number of parts must be an integer...'); return;}			
			if(!subFileCount){alert('You haven\'t Specified the number of subfiles...'); return;}
			if(useCustDir)
			{
				var cd = gebid('in_custDirTxt').value;				
				if(cd)
				{
					var custDir = (cd.charAt(cd.length-1)=='\\')?cd.substring(0,cd.length-1):cd;
					subFilePath = custDir + '\\' + fileBaseName + '_';
					indexFile   = custDir + '\\' + fileBaseName + '.idx';
				}else{alert('Please specify an existing directory(absolute)...'); return;}
			}
			else
				subFilePath = subFileTempl;
			command += ' -S "' + indexFile + '"  "' + filePath + '" "' + subFilePath + '" ' + fileBaseType + ' ' + subFileCount;
		}
		//alert(command);
		return command;
	}
	else
		alert('Please select a file...');	
}
// fileSplitter <-S> "<indexFilePath>" "<mainFilePath>" "<subFileTemplate>" <mainFileType> <numSubFile>
// fileSplitter <-J> "<indexFilePath>" "<outptFilPath>" "<subFileTemplate>" {SPLIT} {1}