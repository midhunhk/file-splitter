
FileSplitter Version 1.9
------------

File Splitting Utility

Centrum inc Software Solutions
June 2007
---------

CommandLine : fs <S> "<indexFilePath>" "<mainFilePath>" "<subFileTemplate>" <mainFileType>  <numSubFile>
            : fs <J> "<indexFilePath>" "<outptFilPath>" "<subFileTemplate>" {SPLIT} 	    {1}

Language    : C,C++

Utility to split a file into a no of small parts. Also reassemble the subfiles to generate the main file.
The program also writes out a log file with the details of the operations.

This utility can be used to split VOB(DVD), MP3 files and each part can play independently.

Features : Calculates the CRC32 of the main file and compares it with the outputted file.
	 : Open SOurce

Source   : Provided, in directory \source